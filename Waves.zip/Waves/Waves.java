import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Waves here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Waves extends Actor
{
    static int sec = 1;
    int min = 0;
    public void act()
    {
        
        update();
        if (sec % 15 == 0) {
            Melee.speed++; 
            sleepFor(60);
        }
        if (sec == 60) {
            sec = 0;
            min++;
            update();
            
        }
    }
    private void update() {
        setImage(new GreenfootImage("Time: " +min +":" +sec, 24, Color.BLACK, new Color(0,0,0,0)));
    }
}
