import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Melee here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Melee extends Actor
{
    /**
     * Act - do whatever the Melee wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public static int speed = 2;
    public void act()
    {
        turnTowards(MyWorld.player.getX(), MyWorld.player.getY()); 
        move(speed / 2);
        
    }
}
