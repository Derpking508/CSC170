import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ranged here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ranged extends Actor
{
    /**
     * Act - do whatever the Ranged wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int count = 0;
    public void act()
    {
        count++;
        turnTowards(MyWorld.player.getX(), MyWorld.player.getY());
        if (count == 60) {
            count = 0;
            Waves.sec++;
            move(10 * Melee.speed);
        }
        
    }
        
    
}
